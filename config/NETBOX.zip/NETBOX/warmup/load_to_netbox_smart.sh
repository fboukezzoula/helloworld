#!/bin/bash

NETBOX_URL="http://localhost:8080/api"
NETBOX_TOKEN="3bac96ea-940b-444a-9757-a9a000282db3"
AUTH_HEADER="Authorization: Token $NETBOX_TOKEN"
CONTENT_HEADER="Content-Type: application/json"
JSON_DIR="./json"

post_all() {
  local file="$1"
  local endpoint="$2"
  jq -c '.[]' "$file" | while read -r item; do
    echo "→ POST $endpoint"
    echo "$item" | curl -s -X POST \
      -H "$AUTH_HEADER" -H "$CONTENT_HEADER" \
      -d @- "$NETBOX_URL/$endpoint/" | jq .
  done
}

get_id() {
  local endpoint="$1"
  local filter="$2"
  curl -s -H "$AUTH_HEADER" "$NETBOX_URL/$endpoint/?limit=1000" | jq -r ".results[] | select($filter) | .id"
}

substitute_ids() {
  local file="$1"
  local output="$2"

  # Get RIR IDs
  local rir_azure=$(get_id "ipam/rirs" '.slug == "azure"')
  local rir_aws=$(get_id "ipam/rirs" '.slug == "aws"')
  local rir_afrinic=$(get_id "ipam/rirs" '.slug == "afrinic"')
  local rir_apnic=$(get_id "ipam/rirs" '.slug == "apnic"')
  local rir_arin=$(get_id "ipam/rirs" '.slug == "arin"')
  local rir_lacnic=$(get_id "ipam/rirs" '.slug == "lacnic"')
  local rir_rfc6598=$(get_id "ipam/rirs" '.slug == "rfc6598"')
  local rir_rfc1918=$(get_id "ipam/rirs" '.slug == "rfc1918"')
  local rir_sgna=$(get_id "ipam/rirs" '.slug == "sgna"')

  # Get Region IDs
  local region_europe=$(get_id "dcim/regions" '.slug == "europe"')

  # Check for missing RIRs
  if [[ -z "$rir_azure" || -z "$rir_aws" || -z "$rir_afrinic" || -z "$rir_apnic" || -z "$rir_arin" || -z "$rir_lacnic" || -z "$rir_rfc6598" || -z "$rir_rfc1918" || -z "$rir_sgna" ]]; then
    echo "❌ One or more RIRs are missing in NetBox. Please import all required RIRs first."
    exit 1
  fi

  jq --arg rir_azure "$rir_azure" \
     --arg rir_aws "$rir_aws" \
     --arg rir_afrinic "$rir_afrinic" \
     --arg rir_apnic "$rir_apnic" \
     --arg rir_arin "$rir_arin" \
     --arg rir_lacnic "$rir_lacnic" \
     --arg rir_rfc6598 "$rir_rfc6598" \
     --arg rir_rfc1918 "$rir_rfc1918" \
     --arg rir_sgna "$rir_sgna" \
     --arg region_europe "$region_europe" \
     '
     map(
       if .rir == "azure" then .rir = ($rir_azure|tonumber)
       elif .rir == "aws" then .rir = ($rir_aws|tonumber)
       elif .rir == "afrinic" then .rir = ($rir_afrinic|tonumber)
       elif .rir == "apnic" then .rir = ($rir_apnic|tonumber)
       elif .rir == "arin" then .rir = ($rir_arin|tonumber)
       elif .rir == "lacnic" then .rir = ($rir_lacnic|tonumber)
       elif .rir == "rfc6598" then .rir = ($rir_rfc6598|tonumber)
       elif .rir == "rfc1918" then .rir = ($rir_rfc1918|tonumber)
       elif .rir == "sgna" then .rir = ($rir_sgna|tonumber)
       else .rir = null
       end
     )
     ' "$file" > "$output"
}


substitute_region_parents() {
  local file="$1"
  local output="$2"

  local europe_id=$(get_id "dcim/regions" '.slug == "europe"')
  local onpremise_id=$(get_id "dcim/regions" '.slug == "onpremise"')

  jq --arg europe_id "$europe_id" \
     --arg onpremise_id "$onpremise_id" \
     '
     map(
       if type == "object" then
         if .parent == "europe" then .parent = ($europe_id|tonumber)
         elif .parent == "onpremise" then .parent = ($onpremise_id|tonumber)
         else .parent
         end
       else empty
       end
     ) | map(select(. != null and . != "" and type == "object"))
     ' "$file" > "$output"
}


substitute_sites() {
  local file="$1"
  local output="$2"

  # Build region and tenant maps
  declare -A region_ids tenant_ids
  while IFS=: read -r slug id; do region_ids["$slug"]=$id; done < <(curl -s -H "$AUTH_HEADER" "$NETBOX_URL/dcim/regions/?limit=1000" | jq -r '.results[] | "\(.slug):\(.id)"')
  while IFS=: read -r slug id; do tenant_ids["$slug"]=$id; done < <(curl -s -H "$AUTH_HEADER" "$NETBOX_URL/tenancy/tenants/?limit=1000" | jq -r '.results[] | "\(.slug):\(.id)"')

  # Build jq args
  local jq_args=""
  for slug in "${!region_ids[@]}"; do
    [[ -n "$slug" ]] && jq_args="$jq_args --arg region_$slug ${region_ids[$slug]}"
  done
  for slug in "${!tenant_ids[@]}"; do
    [[ -n "$slug" ]] && jq_args="$jq_args --arg tenant_$slug ${tenant_ids[$slug]}"
  done

  # Build region substitution cases (skip empty slug)
  local region_cases=""
  for slug in "${!region_ids[@]}"; do
    [[ -n "$slug" ]] && region_cases="$region_cases elif .region == \"$slug\" then .region = (\$region_$slug|tonumber)"
  done
  region_cases="${region_cases:5}" # remove first ' elif'

  # Build tenant substitution cases (skip empty slug)
  local tenant_cases=""
  for slug in "${!tenant_ids[@]}"; do
    [[ -n "$slug" ]] && tenant_cases="$tenant_cases elif .tenant == \"$slug\" then .tenant = (\$tenant_$slug|tonumber)"
  done
  tenant_cases="${tenant_cases:5}"

  # Compose jq filter
  local jq_filter
  if [[ -n "$tenant_cases" ]]; then
    jq_filter="
      map(
        if type == \"object\" then
          (if false $region_cases else .region end)
          | (if false $tenant_cases else .tenant end)
        else empty end
      ) | map(select(. != null and . != \"\" and type == \"object\"))
    "
  else
    jq_filter="
      map(
        if type == \"object\" then
          (if false $region_cases else .region end)
        else empty end
      ) | map(select(. != null and . != \"\" and type == \"object\"))
    "
  fi

  jq $jq_args '
    map(
      if type == "object" and (.region? != null or .tenant? != null) then
        (if false '"$region_cases"' else .region end)
        | (if false '"$tenant_cases"' else .tenant end)
      else empty end
    ) | map(select(. != null and . != "" and type == "object"))
  ' "$file" > "$output"
}


echo "== Bootstrap NetBox =="

echo "[0] Roles"
post_all "$JSON_DIR/01_roles.json" "ipam/roles"


exit 0


echo "[1] RIRs"
post_all "$JSON_DIR/02_rirs.json" "ipam/rirs"

echo "[6] Substituting IDs..."
substitute_ids "$JSON_DIR/05_aggregates.json" "$JSON_DIR/_aggregates.ready.json"

echo "[7] Aggregates"
post_all "$JSON_DIR/_aggregates.ready.json" "ipam/aggregates"

post_all "$JSON_DIR/03_regions_parents.json" "dcim/regions"

substitute_region_parents "$JSON_DIR/03_regions_europe.json" "$JSON_DIR/_regions.ready.json"
post_all "$JSON_DIR/_regions.ready.json" "dcim/regions"

echo "[3] Tenants"
post_all "$JSON_DIR/04_tenants_groups.json" "tenancy/tenant-groups"


substitute_sites "$JSON_DIR/08_sites.json" "$JSON_DIR/_sites.ready.json"
post_all "$JSON_DIR/_sites.ready.json" "dcim/sites"

exit 0



echo "[4] Roles"
post_all "$JSON_DIR/roles.json" "ipam/roles"



echo "[6] Substituting IDs..."
substitute_ids "$JSON_DIR/aggregates.json" "$JSON_DIR/_aggregates.ready.json"

echo "[7] Aggregates"
post_all "$JSON_DIR/_aggregates.ready.json" "ipam/aggregates"

echo "[8] Prefixes"
post_all "$JSON_DIR/_prefixes.ready.json" "ipam/prefixes"

echo "✅ Tout est importé dans NetBox !"
