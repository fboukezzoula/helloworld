kubectl get secret my-release-netbox-superuser -o json | jq '.data | map_values(@base64d)

{
  "api_token": "ee709adb-d13b-41ae-88e8-a3c918ee7070",
  "email": "<admin@example.com>",
  "password": "ogJ76HLuz4",
  "username": "admin"
}

-----

export NETBOX_URL=<http://localhost:8080/>
export NETBOX_TOKEN=ee709adb-d13b-41ae-88e8-a3c918ee7070
python Azure_to_Netbox.py

python Azure_to_Netbox.py --interactive --netbox-url=<http://localhost:8080> --netbox-token=3bac96ea-940b-444a-9757-a9a000282db3 --subscription-id 17aacc5c-13aa-4a84-857b-212f9759ce9d

curl -X POST "<http://localhost:8080/api/extras/custom-fields/>" \
  -H "Authorization: Token ee709adb-d13b-41ae-88e8-a3c918ee7070" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "azure_subscription",
    "label": "Azure Subscription",
    "type": "text",
    "description": "Azure subscription name and ID",
    "object_types": ["ipam.prefix"]
  }'

curl -X POST "<http://localhost:8080/api/extras/custom-fields/>" \
  -H "Authorization: Token ee709adb-d13b-41ae-88e8-a3c918ee7070" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "azure_subscription_url",
    "label": "Azure Subscription URL",
    "type": "url",
    "description": "Direct link to Azure subscription portal",
    "object_types": ["ipam.prefix"]
  }'

  local region_azure=$(get_id "dcim/regions" '.slug == "azure-europe"')
  local region_aws=$(get_id "dcim/regions" '.slug == "aws-europe"')

  local tenant_azure=$(get_id "tenancy/tenants" '.slug == "azure"')
  local tenant_aws=$(get_id "tenancy/tenants" '.slug == "aws"')

  local site_fc=$(get_id "dcim/sites" '.slug == "france-central"')
  local site_we=$(get_id "dcim/sites" '.slug == "west-europe"')
  local site_ew1=$(get_id "dcim/sites" '.slug == "eu-west-1"')
  local site_ew3=$(get_id "dcim/sites" '.slug == "eu-west-3"')

  local role_dev=$(get_id "ipam/roles" '.slug == "dev"')
  local role_test=$(get_id "ipam/roles" '.slug == "test"')
  local role_preprod=$(get_id "ipam/roles" '.slug == "preprod"')
  local role_prod=$(get_id "ipam/roles" '.slug == "prod"')

  jq --argjson site_fc $site_fc \
     --argjson site_we $site_we \
     --argjson site_ew1 $site_ew1 \
     --argjson site_ew3 $site_ew3 \
     --argjson tenant_azure $tenant_azure \
     --argjson tenant_aws $tenant_aws \
     --argjson role_dev $role_dev \
     --argjson role_test $role_test \
     --argjson role_preprod $role_preprod \
     --argjson role_prod $role_prod \
     'map(
        .site = (
          if .description | test("francecentral") then $site_fc
          elif .description | test("westeurope") then $site_we
          elif .description | test("euwest1") then $site_ew1
          else $site_ew3 end
        )
        | .tenant = (
          if .description | test("azure") then $tenant_azure
          else $tenant_aws end
        )
        | .role = (
          if .description | test("dev") then $role_dev
          elif .description | test("test") then $role_test
          elif .description | test("preprod") then $role_preprod
          else $role_prod end
        )
     )' "$JSON_DIR/prefixes.json" > "$JSON_DIR/_prefixes.ready.json"

,
  {
    "name": "North Europe",
    "slug": "northeurope",
    "description": "Azure North Europe (Ireland)",
    "parent": "europe"
  },
  {
    "name": "West Europe",
    "slug": "westeurope",
    "description": "Azure West Europe (Netherlands)",
    "parent": "europe"
  },
  {
    "name": "France Central",
    "slug": "francecentral",
    "description": "Azure France Central (Paris)",
    "parent": "europe"
  },
  {
    "name": "On-Premise",
    "slug": "onpremise",
    "description": "On-premise infrastructure"
  }

3bac96ea-940b-444a-9757-a9a000282db3

az account clear
rm ~/.azure/* -rf
az login --tenant 7f696680-06c9-4377-a4b7-c3a5dd9b7d85 --use-device-code

python Azure_to_Netbox.py --subscription-id 17aacc5c-13aa-4a84-857b-212f9759ce9d --netbox-url http://localhost:8080 --netbox-token=3bac96ea-940b-444a-9757-a9a000282db3