
# Azure Hub-and-Spoke with Azure Firewall and Dual ExpressRoute Routing

## Overview

This package includes:
- A Visio architecture diagram
- Terraform templates for Hub, Spokes, Firewall, and UDRs
- README instructions

## Architecture

- One Hub VNet with Azure Firewall
- Two Spokes (Spoke1, Spoke2)
- One VNet Gateway (connects to on-prem via ExpressRoute)
- Spoke traffic routes to Azure Firewall, then split at on-prem via SNAT

## Deployment Steps

1. Modify `terraform/variables.tf` to set your environment
2. Run Terraform init, plan, and apply:
   ```
   terraform init
   terraform plan
   terraform apply
   ```
3. Configure SNAT rules in Azure Firewall
4. Set up source-based routing on your on-prem router

## Notes

- Azure cannot route based on source IP.
- This solution offloads source-based routing to your on-prem router.
