#!/usr/bin/env python3
"""
Script d'import pour NetBox v4.3.3
Utilise l'API REST pour importer les données depuis les fichiers CSV
"""

import requests
import csv
import json
from urllib.parse import urljoin
import os

# Configuration
NETBOX_URL = "https://your-netbox-instance.com"
NETBOX_TOKEN = "your-api-token-here"
HEADERS = {
    "Authorization": f"Token {NETBOX_TOKEN}",
    "Content-Type": "application/json",
    "Accept": "application/json"
}

def import_csv_to_netbox(csv_file, api_endpoint, field_mapping=None):
    """
    Importe un fichier CSV vers NetBox via l'API
    """
    url = urljoin(NETBOX_URL, f"/api/{api_endpoint}/")
    
    with open(csv_file, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        
        for row in reader:
            # Appliquer le mapping des champs si fourni
            if field_mapping:
                data = {api_field: row[csv_field] for api_field, csv_field in field_mapping.items() if row[csv_field]}
            else:
                data = {k: v for k, v in row.items() if v}
            
            # Traiter les champs booléens
            for key, value in data.items():
                if value.lower() in ['true', 'false']:
                    data[key] = value.lower() == 'true'
            
            response = requests.post(url, headers=HEADERS, json=data)
            
            if response.status_code == 201:
                print(f"✓ Créé: {data.get('name', data.get('prefix', str(data)))}")
            else:
                print(f"✗ Erreur: {response.status_code} - {response.text}")

def main():
    """
    Ordre d'import respectant les dépendances
    """
    
    # 1. Rôles
    print("Import des rôles...")
    import_csv_to_netbox("01_roles.csv", "ipam/roles")
    
    # 2. RIRs
    print("\nImport des RIRs...")
    import_csv_to_netbox("02_rirs.csv", "ipam/rirs")
    
    # 3. Régions
    print("\nImport des régions...")
    import_csv_to_netbox("03_regions.csv", "dcim/regions")
    
    # 4. Tenants
    print("\nImport des tenants...")
    import_csv_to_netbox("04_tenants.csv", "tenancy/tenants")
    
    # 5. Aggregates
    print("\nImport des aggregates...")
    import_csv_to_netbox("05_aggregates.csv", "ipam/aggregates")
    
    # 6. Prefixes
    print("\nImport des prefixes...")
    import_csv_to_netbox("06_prefixes.csv", "ipam/prefixes")
    
    # 7. VLANs
    print("\nImport des VLANs...")
    import_csv_to_netbox("07_vlans.csv", "ipam/vlans")
    
    print("\nImport terminé !")

if __name__ == "__main__":
    main()
