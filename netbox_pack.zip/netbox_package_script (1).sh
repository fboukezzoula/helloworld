#!/bin/bash

# Script de création du package NetBox IPAM
# Génère un fichier ZIP avec tous les composants

PACKAGE_NAME="netbox-ipam-hub-spoke-azure-$(date +%Y%m%d)"
TEMP_DIR="/tmp/$PACKAGE_NAME"

log_info() {
    echo -e "\033[0;32m[INFO]\033[0m $1"
}

log_error() {
    echo -e "\033[0;31m[ERROR]\033[0m $1"
}

# Créer le répertoire temporaire
if [[ -d "$TEMP_DIR" ]]; then
    rm -rf "$TEMP_DIR"
fi
mkdir -p "$TEMP_DIR"

log_info "Création du package dans $TEMP_DIR"

# Copier tous les fichiers CSV
log_info "Copie des fichiers CSV..."
cp 01_roles.csv "$TEMP_DIR/"
cp 02_rirs.csv "$TEMP_DIR/"
cp 03_regions.csv "$TEMP_DIR/"
cp 04_tenants.csv "$TEMP_DIR/"
cp 05_aggregates.csv "$TEMP_DIR/"
cp 06_prefixes.csv "$TEMP_DIR/"
cp 07_circuits_expressroute.csv "$TEMP_DIR/"
cp 08_sites.csv "$TEMP_DIR/"
cp 09_circuit_types.csv "$TEMP_DIR/"
cp 10_providers.csv "$TEMP_DIR/"

# Copier le script d'import
log_info "Copie du script d'import..."
cp import_netbox.sh "$TEMP_DIR/"
chmod +x "$TEMP_DIR/import_netbox.sh"

# Copier la documentation
log_info "Copie de la documentation..."
cp README.md "$TEMP_DIR/"
cp ARCHITECTURE.md "$TEMP_DIR/"
cp TROUBLESHOOTING.md "$TEMP_DIR/"

# Créer un fichier de checksums
log_info "Génération des checksums..."
cd "$TEMP_DIR"
sha256sum *.csv *.sh *.md > checksums.sha256

# Créer le fichier d'informations du package
cat > PACKAGE_INFO.txt << EOF
NetBox IPAM Package - Hub and Spoke Azure
==========================================

Version: 1.0
Date: $(date +"%Y-%m-%d %H:%M:%S")
NetBox Version: v4.3.3+

Contenu:
--------
CSV Files (10):
- 01_roles.csv
- 02_rirs.csv  
- 03_regions.csv
- 04_tenants.csv
- 05_aggregates.csv
- 06_prefixes.csv
- 07_circuits_expressroute.csv
- 08_sites.csv
- 09_circuit_types.csv
- 10_providers.csv

Scripts (1):
- import_netbox.sh

Documentation (3):
- README.md
- ARCHITECTURE.md
- TROUBLESHOOTING.md

Autres:
- checksums.sha256
- PACKAGE_INFO.txt

Installation:
-------------
1. Extraire le ZIP
2. Configurer NETBOX_URL et NETBOX_TOKEN
3. Personnaliser les CSV selon votre environnement
4. Exécuter: ./import_netbox.sh

Support:
--------
Ce package configure NetBox pour une architecture Hub and Spoke
Azure avec ExpressRoute et multi-environnements.

Consultez README.md pour les instructions détaillées.
EOF

cd - > /dev/null

# Créer le ZIP
log_info "Création du fichier ZIP..."
cd /tmp
zip -r "$PACKAGE_NAME.zip" "$PACKAGE_NAME" > /dev/null 2>&1

if [[ $? -eq 0 ]]; then
    log_info "✓ Package créé avec succès: /tmp/$PACKAGE_NAME.zip"
    
    # Afficher le contenu
    echo ""
    echo "Contenu du package:"
    unzip -l "/tmp/$PACKAGE_NAME.zip"
    
    # Afficher les statistiques
    echo ""
    echo "Statistiques:"
    echo "- Taille: $(du -h /tmp/$PACKAGE_NAME.zip | cut -f1)"
    echo "- Fichiers: $(unzip -l /tmp/$PACKAGE_NAME.zip | wc -l) fichiers"
    echo "- Checksum: $(sha256sum /tmp/$PACKAGE_NAME.zip | cut -d' ' -f1)"
    
    # Nettoyer
    rm -rf "$TEMP_DIR"
    
    echo ""
    log_info "Package prêt pour distribution: /tmp/$PACKAGE_NAME.zip"
else
    log_error "Erreur lors de la création du ZIP"
    exit 1
fi
