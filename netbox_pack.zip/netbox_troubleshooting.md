# Guide de dépannage NetBox Import

## Problèmes courants et solutions

### 1. Erreurs de connectivité

#### ❌ Erreur : "Connexion NetBox échouée"
```bash
[ERROR] Connexion NetBox échouée - Code: 000
```

**Causes possibles :**
- URL NetBox incorrecte
- Problème réseau/firewall
- NetBox indisponible

**Solutions :**
```bash
# Vérifier l'URL
curl -I https://your-netbox-instance.com

# Tester la connectivité
ping your-netbox-instance.com

# Vérifier les certificats SSL
curl -k https://your-netbox-instance.com/api/
```

#### ❌ Erreur : "Code: 401 Unauthorized"
```bash
[ERROR] Erreur 401: Line 1 - {"detail":"Authentication credentials were not provided."}
```

**Cause :** Token API invalide ou manquant

**Solutions :**
```bash
# Vérifier le token
export NETBOX_TOKEN="your-real-token"

# Tester le token
curl -H "Authorization: Token $NETBOX_TOKEN" \
     https://your-netbox-instance.com/api/
```

**Générer un nouveau token :**
1. NetBox → Admin → Users → Votre utilisateur
2. API Tokens → Add Token
3. Copier le token généré

### 2. Erreurs de format de données

#### ❌ Erreur : "Code: 400 Bad Request"
```bash
[ERROR] Erreur 400: PROD-NE - {"name":["This field is required."]}
```

**Causes :**
- Champs obligatoires manquants
- Format JSON invalide
- Valeurs non conformes

**Solutions :**
```bash
# Vérifier les champs obligatoires
# Exemple : name, slug sont souvent requis

# Valider le format CSV
# Pas d'espaces dans les headers
# Échappement des virgules dans les valeurs
```

#### ❌ Erreur : Caractères spéciaux dans CSV
```bash
[ERROR] Erreur 400: Description with "quotes" - JSON parse error
```

**Solutions :**
```bash
# Échapper les guillemets dans les descriptions
"Description with ""quotes""" -> OK
"Description with \"quotes\"" -> OK

# Éviter les caractères spéciaux dans les slugs
"north-europe" -> OK
"north_europe" -> OK
"North Europe" -> KO (espaces)
```

### 3. Erreurs de dépendances

#### ❌ Erreur : "Référence non trouvée"
```bash
[ERROR] Erreur 400: azure-ne - {"region":["Invalid pk \"northeurope\" - object does not exist."]}
```

**Cause :** Ordre d'import incorrect

**Solution :** Respecter l'ordre des dépendances :
```bash
1. Roles
2. RIRs  
3. Regions
4. Tenants
5. Sites
6. Providers
7. Circuit Types
8. Aggregates
9. Prefixes
10. Circuits
```

#### ❌ Erreur : "Tenant non trouvé"
```bash
[ERROR] Erreur 400: - {"tenant":["Invalid pk \"prod\" - object does not exist."]}
```

**Solutions :**
```bash
# Vérifier que 04_tenants.csv a été importé
# Vérifier les slugs dans les CSV (doivent correspondre)

# Exemple correct :
# 04_tenants.csv: name=Production, slug=prod
# 06_prefixes.csv: tenant=prod
```

### 4. Problèmes spécifiques aux modules

#### IPAM - Préfixes

**❌ Erreur : "Préfixe invalide"**
```bash
[ERROR] Erreur 400: - {"prefix":["Enter a valid IPv4 or IPv6 network."]}
```

**Solutions :**
```bash
# Vérifier le format CIDR
10.0.1.0/24 -> OK
10.0.1.0/255.255.255.0 -> KO

# Vérifier les ranges valides
10.0.1.0/24 -> OK (RFC1918)
192.168.1.0/24 -> OK (RFC1918)
203.0.113.0/24 -> OK (Public)
```

**❌ Erreur : "Préfixe dupliqué"**
```bash
[WARN] ⚠ Existe déjà ou erreur: 10.0.1.0/24
```

**Solutions :**
```bash
# Normal si re-import
# Vérifier les doublons dans les CSV
# Utiliser des préfixes uniques
```

#### Circuits - ExpressRoute

**❌ Erreur : "Provider non trouvé"**
```bash
[ERROR] Erreur 400: - {"provider":["Invalid pk \"orange-business\" - object does not exist."]}
```

**Solutions :**
```bash
# Importer 10_providers.csv avant 07_circuits_expressroute.csv
# Vérifier les slugs providers
```

#### Sites et Régions

**❌ Erreur : "Région parente non trouvée"**
```bash
[ERROR] Erreur 400: - {"parent":["Invalid pk \"europe\" - object does not exist."]}
```

**Solutions :**
```bash
# Importer les régions dans l'ordre hiérarchique
# Créer d'abord "europe", puis "northeurope"

# Ordre correct dans 03_regions.csv :
1. Europe (parent vide)
2. North Europe (parent=europe)
```

### 5. Problèmes de performance

#### ❌ Import très lent
**Causes :**
- Gros volumes de données
- Latence réseau
- Validation NetBox

**Solutions :**
```bash
# Augmenter les timeouts curl
curl --connect-timeout 30 --max-time 60

# Traitement par batch
# Diviser les gros CSV en plusieurs fichiers

# Parallélisation (attention aux dépendances)
```

### 6. Validation post-import

#### Vérifications recommandées

```bash
# 1. Compter les objets importés
curl -H "Authorization: Token $NETBOX_TOKEN" \
     https://your-netbox-instance.com/api/ipam/prefixes/ | jq '.count'

# 2. Vérifier les aggregates
curl -H "Authorization: Token $NETBOX_TOKEN" \
     https://your-netbox-instance.com/api/ipam/aggregates/

# 3. Tester les recherches
curl -H "Authorization: Token $NETBOX_TOKEN" \
     "https://your-netbox-instance.com/api/ipam/prefixes/?tenant=prod"
```

### 7. Logs et debugging

#### Activer le debug dans le script
```bash
# Ajouter au début du script
set -x  # Debug mode
set -e  # Exit on error

# Ou exécuter avec
bash -x import_netbox.sh
```

#### Examiner les réponses détaillées
```bash
# Modifier le script pour afficher les réponses complètes
echo "Response: $response_body" >&2
```

### 8. Réinitialisation et nettoyage

#### Supprimer les données importées
```bash
# ATTENTION : Cette opération supprime toutes les données !

# Via l'API (exemple pour les préfixes)
curl -X DELETE -H "Authorization: Token $NETBOX_TOKEN" \
     https://your-netbox-instance.com/api/ipam/prefixes/ID/

# Via l'interface web
# Admin → Django Admin → Supprimer les objets par type
```

#### Réinitialisation complète
```bash
# Sauvegarder d'abord !
# Puis utiliser les fixtures Django ou restaurer depuis backup
```

### 9. Bonnes pratiques pour éviter les problèmes

#### Avant l'import
- [ ] Sauvegarder NetBox
- [ ] Valider les CSV (pas d'espaces, formats corrects)
- [ ] Tester sur un petit échantillon
- [ ] Vérifier les dépendances

#### Pendant l'import
- [ ] Surveiller les logs
- [ ] Vérifier les erreurs 400/401
- [ ] Valider les objets créés

#### Après l'import
- [ ] Vérifier les compteurs
- [ ] Tester les recherches
- [ ] Valider l'intégrité des données

### 10. Ressources utiles

#### Documentation
- [NetBox API Documentation](https://demo.netbox.dev/api/docs/)
- [NetBox GitHub Issues](https://github.com/netbox-community/netbox/issues)

#### Outils
- [jq](https://stedolan.github.io/jq/) : Parser JSON
- [curl](https://curl.se/) : Client HTTP
- [csvkit](https://csvkit.readthedocs.io/) : Validation CSV

#### Communauté
- [NetBox Slack](https://netbox.dev/slack/)
- [Reddit r/netbox](https://www.reddit.com/r/netbox/)

---

**En cas de problème persistant :**
1. Vérifier les logs NetBox (/opt/netbox/logs/)
2. Consulter la documentation officielle
3. Poser la question sur la communauté NetBox