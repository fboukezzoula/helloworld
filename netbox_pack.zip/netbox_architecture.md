# Architecture réseau Hub and Spoke Azure

## Vue d'ensemble

Cette architecture implémente un modèle **Hub and Spoke** sur Azure avec connectivité hybride via ExpressRoute, optimisée pour la gestion multi-environnements et multi-régions.

## Topologie réseau

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   On-Premise    │    │   Azure Hub     │    │  Azure Spokes   │
│                 │    │                 │    │                 │
│ Paris HQ        │────│ North Europe    │────│ Prod/HML/UAT    │
│ 172.16.0.0/24   │    │ 10.1.1.0/24     │    │ 10.0.x.0/24     │
│                 │    │                 │    │                 │
│ ExpressRoute    │    │ West Europe     │    │ Development     │
│ Peering         │────│ 10.1.2.0/24     │────│ 10.0.3x.0/24    │
│ 10.0.201.x/30   │    │                 │    │                 │
│                 │    │ France Central  │    │                 │
│                 │────│ 10.1.3.0/24     │────│                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Segmentation réseau

### 1. Hub VNets (Transit)
- **Rôle** : Centralisation du trafic, services partagés
- **Régions** : North Europe (principal), West Europe (backup), France Central
- **Adressage** : 10.1.0.0/16

#### Détail des hubs
| Région | Subnet | Usage | Redondance |
|--------|--------|-------|------------|
| North Europe | 10.1.1.0/24 | Hub principal | ExpressRoute primaire |
| West Europe | 10.1.2.0/24 | Hub backup | ExpressRoute backup |
| France Central | 10.1.3.0/24 | Hub local | ExpressRoute local |

### 2. Spoke VNets (Environnements)
- **Rôle** : Hébergement des applications par environnement
- **Isolation** : Par tenant et environnement
- **Adressage** : 10.0.0.0/16

#### Matrice d'adressage
| Environnement | North Europe | West Europe | France Central |
|---------------|--------------|-------------|----------------|
| **Production** | 10.0.1.0/24 | 10.0.2.0/24 | 10.0.3.0/24 |
| **Homologation** | 10.0.10.0/24 | 10.0.11.0/24 | 10.0.12.0/24 |
| **UAT** | 10.0.20.0/24 | 10.0.21.0/24 | 10.0.22.0/24 |
| **Development** | 10.0.30.0/24 | 10.0.31.0/24 | 10.0.32.0/24 |

### 3. Services partagés
- **Management** : 10.0.100.0/24 (par région)
- **Monitoring** : 10.1.10.0/24 (par région)
- **Shared Services** : 10.1.1x.0/24 (par région)

## Connectivité ExpressRoute

### Architecture de redondance
```
On-Premise ── ExpressRoute Primary ── Azure North Europe (Hub)
    │                                       │
    └─── ExpressRoute Backup ──── Azure West Europe (Hub)
```

### Circuits ExpressRoute

#### Circuits principaux
| Circuit | Bande passante | Région | Provider | Type |
|---------|---------------|--------|----------|------|
| ER-HUB-001 | 2 Gbps | North Europe | Orange Business | Principal |
| ER-HUB-002 | 2 Gbps | West Europe | Orange Business | Backup |

#### Circuits par région
| Région | Circuit | Bande passante | Backup |
|--------|---------|---------------|--------|
| North Europe | ER-NE-001 | 1 Gbps | ER-NE-002 (500 Mbps) |
| West Europe | ER-WE-001 | 1 Gbps | ER-WE-002 (500 Mbps) |
| France Central | ER-FC-001 | 1 Gbps | ER-FC-002 (500 Mbps) |

### Peering ExpressRoute
- **Type** : Private Peering
- **Adressage** : 10.0.201.0/24
- **Répartition** :
  - 10.0.201.0/30 : North Europe
  - 10.0.201.4/30 : West Europe
  - 10.0.201.8/30 : France Central

## Routage et connectivité

### Flux principaux
1. **On-premise → Azure** : Via ExpressRoute vers Hub, puis vers Spokes
2. **Azure → On-premise** : Via Hub ExpressRoute Gateway
3. **Spoke → Spoke** : Via Hub (transit)
4. **Internet** : Via Hub (NAT Gateway ou Azure Firewall)

### Sécurité réseau
- **NSG** : Par subnet et environnement
- **Azure Firewall** : Dans le Hub pour filtrage centralisé
- **Route Tables** : Contrôle du routage Hub/Spoke

## Adressage IP public

### BGP Public
- **Usage** : Load balancers, services exposés
- **Ranges** : 203.0.113.0/24, 198.51.100.0/24 (exemples)
- **Répartition** :
  - Production : 203.0.113.0/28
  - Load Balancers : 203.0.113.16/28
  - APIs externes : 198.51.100.0/28

### Gestion des IP publiques
- **Allocation** : Par environnement et usage
- **Monitoring** : Suivi de l'utilisation
- **Documentation** : Traçabilité dans NetBox

## Scalabilité et évolution

### Ajout d'un environnement
1. Définir le tenant dans NetBox
2. Allouer les subnets (10.0.4x.0/24)
3. Configurer les NSG et routes
4. Tester la connectivité

### Nouvelle région Azure
1. Créer le Hub VNet
2. Configurer ExpressRoute
3. Établir le peering
4. Déployer les Spokes

### Optimisations futures
- **Azure Virtual WAN** : Migration possible
- **Global Reach** : Interconnexion ExpressRoute
- **IPv6** : Support dual-stack

## Monitoring et observabilité

### Métriques clés
- **Utilisation bande passante** ExpressRoute
- **Latence** inter-régions
- **Disponibilité** des circuits
- **Consommation IP** par environnement

### Outils recommandés
- **Azure Monitor** : Métriques ExpressRoute
- **Network Watcher** : Diagnostic réseau
- **NetBox** : Gestion IPAM
- **Grafana** : Dashboards personnalisés

## Bonnes pratiques

### Sécurité
- Segmentation stricte par environnement
- Chiffrement en transit (ExpressRoute)
- Audit régulier des accès

### Performance
- Placement des workloads par région
- Optimisation des routes
- Surveillance continue

### Coûts
- Dimensionnement approprié ExpressRoute
- Optimisation du trafic inter-régions
- Révision périodique des besoins

---

**Note** : Cette architecture est conçue pour évoluer avec la croissance de l'infrastructure et s'adapter aux besoins métier.