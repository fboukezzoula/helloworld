# NetBox IPAM - Import Configuration Hub and Spoke Azure

## Vue d'ensemble

Ce package contient tous les fichiers nécessaires pour configurer NetBox v4.3.3 avec une architecture **Hub and Spoke** sur Azure, incluant les circuits ExpressRoute et la gestion multi-environnements.

## Architecture cible

- **3 régions Azure** : North Europe (hub principal), West Europe (backup), France Central
- **4 environnements** : Production, Homologation, UAT, Development
- **Topologie Hub and Spoke** avec ExpressRoute
- **Connectivité hybride** : On-premise ↔ Azure via ExpressRoute
- **IP publiques BGP** + **RFC1918 privées**

## Contenu du package

### 📁 Fichiers CSV (ordre d'import)
```
01_roles.csv              - Rôles par environnement et type réseau
02_rirs.csv               - Registres IP (RIPE, RFC1918, Azure)
03_regions.csv            - Régions Azure + On-premise
04_tenants.csv            - Tenants par environnement
05_aggregates.csv         - Blocs IP principaux
06_prefixes.csv           - Détail des subnets par région/environnement
07_circuits_expressroute.csv - Circuits ExpressRoute avec specs
08_sites.csv              - Sites Azure et datacenters
09_circuit_types.csv      - Types de circuits réseau
10_providers.csv          - Fournisseurs (Orange, Equinix, Microsoft)
```

### 📁 Scripts
```
import_netbox.sh          - Script d'import principal
```

### 📁 Documentation
```
README.md                 - Ce fichier
ARCHITECTURE.md           - Détails architecture réseau
TROUBLESHOOTING.md        - Guide de dépannage
```

## Prérequis

### NetBox
- **Version** : v4.3.3 minimum
- **Token API** : Avec droits d'écriture sur tous les modules
- **Modules requis** : IPAM, DCIM, Circuits, Tenancy

### Système
- **OS** : Linux/Unix avec bash
- **Outils** : curl, standard Unix tools
- **Accès réseau** : Connectivité HTTPS vers NetBox

## Installation rapide

### 1. Configuration
```bash
# Éditer les variables dans le script
export NETBOX_URL="https://your-netbox-instance.com"
export NETBOX_TOKEN="your-api-token-here"
```

### 2. Personnalisation des données

⚠️ **IMPORTANT** : Adaptez les fichiers CSV à votre environnement :

**Dans `05_aggregates.csv` et `06_prefixes.csv`** :
- Remplacez `203.0.113.0/24` et `198.51.100.0/24` par vos vraies IP publiques BGP
- Ajustez les ranges RFC1918 selon votre plan d'adressage

**Dans `07_circuits_expressroute.csv`** :
- Modifiez les IDs circuits selon vos contrats
- Ajustez les bandes passantes réelles
- Corrigez les endpoints de terminaison

**Dans `10_providers.csv`** :
- Complétez les contacts NOC réels
- Ajustez les numéros de compte

### 3. Exécution
```bash
chmod +x import_netbox.sh
./import_netbox.sh
```

## Plan d'adressage proposé

### Hub VNet (Transit)
- **10.1.0.0/16** : Supernet Hub
- **10.1.1.0/24** : Hub North Europe (principal)
- **10.1.2.0/24** : Hub West Europe (backup)
- **10.1.3.0/24** : Hub France Central

### Spoke VNets (par environnement)
- **Production** : 10.0.1.0/24, 10.0.2.0/24, 10.0.3.0/24
- **Homologation** : 10.0.10.0/24, 10.0.11.0/24, 10.0.12.0/24
- **UAT** : 10.0.20.0/24, 10.0.21.0/24, 10.0.22.0/24
- **Development** : 10.0.30.0/24, 10.0.31.0/24, 10.0.32.0/24

### ExpressRoute Peering
- **10.0.201.0/30** : Peering North Europe
- **10.0.201.4/30** : Peering West Europe
- **10.0.201.8/30** : Peering France Central

### Services partagés
- **10.1.10.0/24** : Shared services North Europe
- **10.1.11.0/24** : Shared services West Europe
- **10.1.12.0/24** : Shared services France Central

## Bonnes pratiques

### Sécurité
- Utilisez des tokens API avec droits minimaux
- Rotez régulièrement les tokens
- Auditez les accès NetBox

### Maintenance
- Sauvegardez NetBox avant l'import
- Testez d'abord sur un environnement de dev
- Documentez les modifications post-import

### Monitoring
- Surveillez l'utilisation des préfixes
- Alertes sur les seuils d'allocation
- Audit régulier des circuits ExpressRoute

## Personnalisations courantes

### Ajouter un nouvel environnement
1. Créer le tenant dans `04_tenants.csv`
2. Ajouter le rôle dans `01_roles.csv`
3. Définir les préfixes dans `06_prefixes.csv`

### Nouvelle région Azure
1. Ajouter dans `03_regions.csv`
2. Créer le site dans `08_sites.csv`
3. Définir les subnets correspondants
4. Configurer les circuits ExpressRoute

### Nouveau circuit ExpressRoute
1. Ajouter dans `07_circuits_expressroute.csv`
2. Définir les subnets de peering
3. Mettre à jour la documentation

## Validation post-import

### Vérifications NetBox
- [ ] Tous les rôles sont créés
- [ ] Hiérarchie des régions correcte
- [ ] Aggregates et préfixes cohérents
- [ ] Circuits ExpressRoute avec specs
- [ ] Sites et providers configurés

### Tests fonctionnels
- [ ] Recherche par tenant
- [ ] Filtrage par rôle
- [ ] Rapport d'utilisation IP
- [ ] Validation des circuits

## Support

### Logs et debugging
Le script génère des logs détaillés avec codes couleur :
- 🟢 **INFO** : Opérations réussies
- 🟡 **WARN** : Éléments existants ou avertissements
- 🔴 **ERROR** : Échecs d'import

### Résolution des problèmes courants
Consultez `TROUBLESHOOTING.md` pour les erreurs fréquentes.

### Ressources
- [Documentation NetBox](https://docs.netbox.dev/)
- [API NetBox](https://demo.netbox.dev/api/docs/)
- [Azure ExpressRoute](https://docs.microsoft.com/en-us/azure/expressroute/)

---

**Version** : 1.0  
**Dernière mise à jour** : Juillet 2025  
**Compatibilité** : NetBox v4.3.3+