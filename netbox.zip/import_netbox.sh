#!/bin/bash

# Script d'import NetBox v4.3.3 - Hub and Spoke Azure avec ExpressRoute
# Configuration
NETBOX_URL="https://your-netbox-instance.com"
NETBOX_TOKEN="your-api-token-here"
HEADERS="Authorization: Token $NETBOX_TOKEN"

# Couleurs pour les logs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Fonction pour importer un CSV vers NetBox
import_csv() {
    local csv_file="$1"
    local api_endpoint="$2"
    local url="${NETBOX_URL}/api/${api_endpoint}/"
    
    log_info "Import de $csv_file vers $api_endpoint"
    
    if [[ ! -f "$csv_file" ]]; then
        log_error "Fichier $csv_file non trouvé"
        return 1
    fi
    
    # Lire le header
    local header=$(head -n1 "$csv_file")
    local fields=($(echo "$header" | tr ',' '\n'))
    
    # Traiter chaque ligne (skip header)
    local line_count=0
    tail -n +2 "$csv_file" | while IFS=, read -r line; do
        ((line_count++))
        
        # Échapper les caractères spéciaux et construire le JSON
        local values=($(echo "$line" | sed 's/","/\n/g' | sed 's/^"//; s/"$//'))
        local json_data="{"
        
        for i in "${!fields[@]}"; do
            local field="${fields[$i]}"
            local value="${values[$i]}"
            
            # Nettoyer les champs
            field=$(echo "$field" | tr -d '"')
            value=$(echo "$value" | tr -d '"')
            
            # Ignorer les champs vides
            if [[ -n "$value" ]]; then
                # Traiter les booléens
                if [[ "$value" == "true" || "$value" == "false" ]]; then
                    json_data="$json_data\"$field\": $value,"
                else
                    json_data="$json_data\"$field\": \"$value\","
                fi
            fi
        done
        
        # Retirer la dernière virgule et fermer le JSON
        json_data="${json_data%,}}"
        
        # Envoyer la requête
        response=$(curl -s -w "%{http_code}" -X POST \
            -H "Content-Type: application/json" \
            -H "$HEADERS" \
            -d "$json_data" \
            "$url")
        
        # Extraire le code de statut
        http_code="${response: -3}"
        response_body="${response%???}"
        
        # Extraire le nom pour le log
        local name=$(echo "$json_data" | grep -o '"name":"[^"]*' | cut -d'"' -f4)
        if [[ -z "$name" ]]; then
            name=$(echo "$json_data" | grep -o '"prefix":"[^"]*' | cut -d'"' -f4)
        fi
        if [[ -z "$name" ]]; then
            name=$(echo "$json_data" | grep -o '"circuit_id":"[^"]*' | cut -d'"' -f4)
        fi
        [[ -z "$name" ]] && name="Line $line_count"
        
        if [[ "$http_code" == "201" ]]; then
            log_info "✓ Créé: $name"
        elif [[ "$http_code" == "400" ]]; then
            log_warn "⚠ Existe déjà ou erreur: $name"
        else
            log_error "✗ Erreur $http_code: $name - $response_body"
        fi
    done
}

# Fonction pour vérifier la connectivité NetBox
check_netbox_connectivity() {
    log_info "Vérification de la connectivité NetBox..."
    
    response=$(curl -s -w "%{http_code}" -X GET \
        -H "$HEADERS" \
        "${NETBOX_URL}/api/")
    
    http_code="${response: -3}"
    
    if [[ "$http_code" == "200" ]]; then
        log_info "✓ Connexion NetBox OK"
        return 0
    else
        log_error "✗ Connexion NetBox échouée - Code: $http_code"
        return 1
    fi
}

# Fonction principale
main() {
    log_info "Début de l'import NetBox - Architecture Hub and Spoke Azure"
    
    # Vérifier la connectivité
    if ! check_netbox_connectivity; then
        log_error "Impossible de se connecter à NetBox. Vérifiez l'URL et le token."
        exit 1
    fi
    
    # Liste des imports dans l'ordre des dépendances
    declare -a imports=(
        "01_roles.csv:ipam/roles"
        "02_rirs.csv:ipam/rirs"
        "03_regions.csv:dcim/regions"
        "04_tenants.csv:tenancy/tenants"
        "08_sites.csv:dcim/sites"
        "10_providers.csv:circuits/providers"
        "09_circuit_types.csv:circuits/circuit-types"
        "05_aggregates.csv:ipam/aggregates"
        "06_prefixes.csv:ipam/prefixes"
        "07_circuits_expressroute.csv:circuits/circuits"
    )
    
    # Exécuter les imports
    for import_def in "${imports[@]}"; do
        IFS=':' read -r csv_file api_endpoint <<< "$import_def"
        import_csv "$csv_file" "$api_endpoint"
        echo ""
    done
    
    log_info "Import terminé !"
    log_info "Points de vérification:"
    log_info "- Vérifiez les aggregates et prefixes dans IPAM"
    log_info "- Contrôlez les circuits ExpressRoute"
    log_info "- Validez la hiérarchie des régions"
    log_info "- Testez les recherches par tenant et rôle"
}

# Vérifier les prérequis
if ! command -v curl &> /dev/null; then
    log_error "curl n'est pas installé"
    exit 1
fi

if [[ -z "$NETBOX_TOKEN" || "$NETBOX_TOKEN" == "your-api-token-here" ]]; then
    log_error "Veuillez configurer NETBOX_TOKEN"
    exit 1
fi

if [[ -z "$NETBOX_URL" || "$NETBOX_URL" == "https://your-netbox-instance.com" ]]; then
    log_error "Veuillez configurer NETBOX_URL"
    exit 1
fi

# Exécuter
main "$@"