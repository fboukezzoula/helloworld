# Exemples de requêtes API NetBox

## 🔍 Requêtes de base

### Authentification et test de connectivité

```bash
# Test de base
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/" | jq '.'

# Informations sur l'instance
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/status/" | jq '.'
```

## 📊 Requêtes IPAM

### Gestion des prefixes

```bash
# Lister tous les prefixes
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/" | jq '.results[]'

# Prefixes par tenant
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?tenant=prod" | jq '.results[]'

# Prefixes par région
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?region=northeurope" | jq '.results[]'

# Prefixes disponibles (statut container)
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?status=container" | jq '.results[]'
```

### Recherche d'IPs disponibles

```bash
# IPs libres dans un prefix (ID 1)
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/1/available-ips/" | jq '.'

# Première IP disponible
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/1/available-ips/" | jq '.[0]'

# Prefixes enfants d'un aggregate
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/aggregates/1/prefixes/" | jq '.results[]'
```

### Utilisation des ranges

```bash
# Utilisation par prefix
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/" | \
  jq '.results[] | {prefix: .prefix, utilization: .utilization}'

# Prefixes les plus utilisés
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?utilization__gte=80" | \
  jq '.results[] | {prefix: .prefix, utilization: .utilization}'
```

## 🔌 Requêtes Circuits

### Gestion des circuits

```bash
# Tous les circuits
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/" | jq '.results[]'

# Circuits ExpressRoute
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?type=expressroute" | jq '.results[]'

# Circuits par provider
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?provider=orange-business" | jq '.results[]'

# Circuits par région
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?region=northeurope" | jq '.results[]'
```

### Statistiques circuits

```bash
# Circuits par statut
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/" | \
  jq '.results | group_by(.status.label) | map({status: .[0].status.label, count: length})'

# Bande passante totale par provider
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/" | \
  jq '.results | group_by(.provider.name) | map({provider: .[0].provider.name, total_bandwidth: map(.bandwidth) | add})'
```

## 🏢 Requêtes Tenancy et Sites

### Gestion des tenants

```bash
# Tous les tenants
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/tenancy/tenants/" | jq '.results[]'

# Ressources par tenant
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?tenant=prod" | \
  jq '.results | length'
```

### Gestion des sites

```bash
# Tous les sites
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/dcim/sites/" | jq '.results[]'

# Sites par région
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/dcim/sites/?region=northeurope" | jq '.results[]'

# Sites Azure uniquement
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/dcim/sites/?name__icontains=azure" | jq '.results[]'
```

## 📈 Requêtes de reporting

### Rapport d'utilisation globale

```bash
# Utilisation par environnement
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/" | \
  jq '.results | group_by(.tenant.name) | map({tenant: .[0].tenant.name, prefixes: length, total_utilization: map(.utilization) | add})'

# Rapport par région
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/" | \
  jq '.results | group_by(.region.name) | map({region: .[0].region.name, prefixes: length})'
```

### Rapport des circuits

```bash
# Synthèse circuits ExpressRoute
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?type=expressroute" | \
  jq '.results | {total_circuits: length, total_bandwidth: map(.bandwidth) | add, active_circuits: map(select(.status.value == "active")) | length}'

# Circuits par région avec détails
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?type=expressroute" | \
  jq '.results | group_by(.region.name) | map({region: .[0].region.name, circuits: map({id: .circuit_id, bandwidth: .bandwidth, status: .status.label})})'
```

## 🔧 Requêtes de maintenance

### Validation des données

```bash
# Prefixes orphelins (sans tenant)
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?tenant__isnull=true" | \
  jq '.results[] | {prefix: .prefix, description: .description}'

# Circuits sans description
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?description__isnull=true" | \
  jq '.results[] | {circuit_id: .circuit_id, provider: .provider.name}'

# Prefixes avec utilisation élevée
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?utilization__gte=90" | \
  jq '.results[] | {prefix: .prefix, utilization: .utilization, tenant: .tenant.name}'
```

### Nettoyage et optimisation

```bash
# Prefixes non utilisés (utilisation = 0)
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?utilization=0" | \
  jq '.results[] | {prefix: .prefix, tenant: .tenant.name, description: .description}'

# Circuits inactifs
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?status=offline" | \
  jq '.results[] | {circuit_id: .circuit_id, provider: .provider.name, description: .description}'
```

## 🔍 Requêtes avancées

### Recherche par critères multiples

```bash
# Prefixes production actifs en North Europe
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?tenant=prod&status=active&region=northeurope" | \
  jq '.results[] | {prefix: .prefix, utilization: .utilization}'

# Circuits ExpressRoute actifs avec bande passante > 500 Mbps
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?type=expressroute&status=active&bandwidth__gte=500" | \
  jq '.results[] | {circuit_id: .circuit_id, bandwidth: .bandwidth, region: .region.name}'
```

### Recherche par pattern

```bash
# Prefixes contenant "prod" dans la description
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?description__icontains=prod" | \
  jq '.results[] | {prefix: .prefix, description: .description}'

# Circuits avec ID contenant "HUB"
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?circuit_id__icontains=HUB" | \
  jq '.results[] | {circuit_id: .circuit_id, bandwidth: .bandwidth}'
```

## 📊 Export et sauvegarde

### Export complet

```bash
# Export tous les prefixes en CSV
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?format=csv" > prefixes_export.csv

# Export circuits en JSON
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/" > circuits_backup.json
```

### Scripts de monitoring

```bash
#!/bin/bash
# Monitoring quotidien

# Alertes utilisation > 85%
curl -s -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?utilization__gte=85" | \
  jq '.results[] | {prefix: .prefix, utilization: .utilization}' | \
  mail -s "NetBox - Prefixes saturés" admin@domain.com

# Circuits inactifs
curl -s -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?status=offline" | \
  jq '.results[] | {circuit_id: .circuit_id, provider: .provider.name}' | \
  mail -s "NetBox - Circuits inactifs" admin@domain.com
```

---

**💡 Conseils** :
- Utiliser `jq` pour formatter les réponses JSON
- Combiner avec `watch` pour monitoring temps réel
- Créer des alias pour les requêtes fréquentes
- Paginer les résultats pour les gros volumes