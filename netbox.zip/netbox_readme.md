# NetBox IPAM - Configuration Hub and Spoke Azure

## 📋 Vue d'ensemble

Ce package contient les fichiers CSV et scripts pour configurer NetBox v4.3.3 avec une architecture **Hub and Spoke** Azure multi-régions avec ExpressRoute.

### Architecture cible :
- **Hub** : VNet central pour transit (10.1.x.x)
- **Spokes** : VNets par environnement (10.0.x.x)
- **Régions** : North Europe, West Europe, France Central
- **Environnements** : dev, uat, hml, prod
- **Connectivité** : ExpressRoute avec circuits primaires/backup

## 📁 Structure des fichiers

```
netbox-ipam-package/
├── README.md                    # Cette documentation
├── CONFIGURATION.md             # Guide de configuration
├── import_netbox.sh             # Script d'import principal
├── csv/
│   ├── 01_roles.csv            # Rôles IPAM
│   ├── 02_rirs.csv             # Registres IP
│   ├── 03_regions.csv          # Régions géographiques
│   ├── 04_tenants.csv          # Tenants par environnement
│   ├── 05_aggregates.csv       # Blocs IP principaux
│   ├── 06_prefixes.csv         # Subnets détaillés
│   ├── 07_circuits_expressroute.csv # Circuits ExpressRoute
│   ├── 08_sites.csv            # Sites et datacenters
│   ├── 09_circuit_types.csv    # Types de circuits
│   └── 10_providers.csv        # Fournisseurs réseau
└── examples/
    └── api_queries.md          # Exemples de requêtes API
```

## 🚀 Installation rapide

### Prérequis
- NetBox v4.3.3+
- curl installé
- Accès API NetBox avec token

### Configuration
```bash
# 1. Configurer les variables d'environnement
export NETBOX_URL="https://your-netbox-instance.com"
export NETBOX_TOKEN="your-api-token-here"

# 2. Rendre le script exécutable
chmod +x import_netbox.sh

# 3. Lancer l'import
./import_netbox.sh
```

## 📊 Plan d'adressage

### Répartition des ranges IP

| Range | Usage | Description |
|-------|-------|-------------|
| `10.0.0.0/16` | Spokes | Environnements applicatifs |
| `10.1.0.0/16` | Hub | VNet de transit central |
| `10.0.200.0/24` | ExpressRoute | Gateways et peering |
| `172.16.0.0/24` | On-premise | Réseau LAN corporate |
| `203.0.113.0/24` | BGP Public | IPs routables publiques |

### Découpage par environnement

| Environnement | Range | Régions |
|---------------|-------|---------|
| Production | `10.0.1.0/24` - `10.0.3.0/24` | NE, WE, FC |
| Homologation | `10.0.10.0/24` - `10.0.12.0/24` | NE, WE, FC |
| UAT | `10.0.20.0/24` - `10.0.22.0/24` | NE, WE, FC |
| Development | `10.0.30.0/24` - `10.0.32.0/24` | NE, WE, FC |

## 🔌 Circuits ExpressRoute

### Configuration par région

| Circuit | Provider | Bande passante | Type | Région |
|---------|----------|----------------|------|---------|
| ER-NE-001 | Orange Business | 1 Gbps | Primary | North Europe |
| ER-NE-002 | Orange Business | 500 Mbps | Backup | North Europe |
| ER-WE-001 | Orange Business | 1 Gbps | Primary | West Europe |
| ER-WE-002 | Orange Business | 500 Mbps | Backup | West Europe |
| ER-FC-001 | Orange Business | 1 Gbps | Primary | France Central |
| ER-FC-002 | Orange Business | 500 Mbps | Backup | France Central |
| ER-HUB-001 | Orange Business | 2 Gbps | Hub Primary | North Europe |
| ER-HUB-002 | Orange Business | 2 Gbps | Hub Backup | West Europe |

## ⚙️ Personnalisation

### Avant l'import, adaptez :

1. **Ranges IP** dans `05_aggregates.csv` et `06_prefixes.csv`
2. **Providers** dans `10_providers.csv`
3. **Circuits** dans `07_circuits_expressroute.csv`
4. **Sites** dans `08_sites.csv`

### Variables du script :
```bash
# Dans import_netbox.sh
NETBOX_URL="https://your-netbox-instance.com"
NETBOX_TOKEN="your-api-token-here"
```

## 🔍 Vérifications post-import

### Tests recommandés :
1. **Hiérarchie** : Régions > Sites > Circuits
2. **IPAM** : Aggregates > Prefixes > Disponibilité
3. **Tenants** : Isolation par environnement
4. **Circuits** : Providers > Types > Circuits

### Requêtes de validation :
```bash
# Vérifier les prefixes par tenant
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?tenant=prod"

# Lister les circuits ExpressRoute
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?type=expressroute"
```

## 📝 Bonnes pratiques

### Gestion des changements :
- **Backup** : Exporter la config avant modifications
- **Staging** : Tester sur un environnement de dev
- **Documentation** : Maintenir les descriptions à jour

### Évolutions futures :
- Ajout de nouvelles régions Azure
- Intégration avec des outils de monitoring
- Automatisation des mises à jour via CI/CD

## 🛠️ Dépannage

### Erreurs communes :

**Erreur 401 - Unauthorized**
```bash
# Vérifier le token
curl -H "Authorization: Token $NETBOX_TOKEN" "$NETBOX_URL/api/"
```

**Erreur 400 - Bad Request**
```bash
# Vérifier le format des données
# Logs détaillés dans le script
```

**Erreur de dépendance**
```bash
# Respecter l'ordre d'import
# Vérifier les références (tenant, region, etc.)
```

## 📞 Support

### Ressources utiles :
- [Documentation NetBox](https://docs.netbox.dev/)
- [API NetBox](https://docs.netbox.dev/en/stable/rest-api/)
- [Azure ExpressRoute](https://docs.microsoft.com/azure/expressroute/)

### Fichiers de logs :
- Script : sortie standard colorée
- NetBox : `/opt/netbox/logs/`
- Système : `/var/log/netbox/`

---

**Version** : 1.0
**Dernière mise à jour** : Juillet 2025
**Compatibilité** : NetBox v4.3.3+