# Guide de Configuration NetBox IPAM

## 🔧 Configuration initiale

### 1. Prérequis NetBox

**Version requise** : NetBox v4.3.3 ou supérieure

**Modules nécessaires** :
- IPAM (IP Address Management)
- Circuits
- DCIM (Data Center Infrastructure Management)
- Tenancy

### 2. Configuration des permissions

**Création d'un utilisateur API** :
```bash
# Dans l'interface NetBox
Admin → Users → Add User
- Username: netbox-importer
- Permissions: Can add/change/delete pour tous les objets IPAM/Circuits/DCIM
```

**Génération du token API** :
```bash
Admin → API Tokens → Add Token
- User: netbox-importer
- Write: True
- Description: Import CSV hub-spoke Azure
```

### 3. Variables d'environnement

**Méthode 1 - Export temporaire** :
```bash
export NETBOX_URL="https://netbox.votre-domaine.com"
export NETBOX_TOKEN="votre-token-api-ici"
```

**Méthode 2 - Fichier .env** :
```bash
# Créer un fichier .env
cat > .env << EOF
NETBOX_URL=https://netbox.votre-domaine.com
NETBOX_TOKEN=votre-token-api-ici
EOF

# Sourcer le fichier
source .env
```

## 📋 Personnalisation des données

### 1. Adaptation des ranges IP

**Modifier `05_aggregates.csv`** :
```csv
# Remplacer les exemples par vos ranges réels
prefix,rir,description
10.0.0.0/8,rfc1918,Votre range corporate principal
203.0.113.0/24,ripe,Remplacer par votre range BGP réel
```

**Modifier `06_prefixes.csv`** :
```csv
# Adapter selon votre plan d'adressage
prefix,status,role,tenant,region,description
10.50.1.0/24,active,prod,prod,northeurope,Production réelle NE
```

### 2. Configuration des providers

**Modifier `10_providers.csv`** :
```csv
# Adapter selon vos fournisseurs
name,slug,account,portal_url,noc_contact,admin_contact,comments
Orange Business,orange-business,VOTRE-COMPTE,https://businesslounge.orange.com,+33-1-votre-noc,votre-contact@orange.com,Votre fournisseur principal
```

### 3. Circuits ExpressRoute

**Modifier `07_circuits_expressroute.csv`** :
```csv
# Adapter selon vos circuits réels
circuit_id,provider,type,status,tenant,bandwidth,region,description,termination_a,termination_z,comments
ER-PROD-001,orange-business,ExpressRoute,active,expressroute,1000,northeurope,Circuit production,Votre DC,Azure NE,Circuit principal
```

## 🏗️ Architecture réseau

### 1. Topologie Hub and Spoke

```
┌─────────────────┐
│   On-Premise    │
│  172.16.0.0/24  │
└─────────┬───────┘
          │ ExpressRoute
          │
┌─────────▼───────┐
│   Azure Hub     │
│  10.1.0.0/16    │
│  (North Europe) │
└─────────┬───────┘
          │
    ┌─────┼─────┐
    │     │     │
┌───▼─┐ ┌─▼─┐ ┌─▼───┐
│ DEV │ │UAT│ │PROD │
│Spoke│ │Spk│ │Spoke│
└─────┘ └───┘ └─────┘
```

### 2. Plan d'adressage recommandé

**Structure hiérarchique** :
- `10.0.0.0/8` : Supernet corporate
- `10.1.0.0/16` : Hub VNets
- `10.0.0.0/16` : Spoke VNets
- `10.2.0.0/16` : Réservé extension

**Découpage par environnement** :
- Production : `10.0.1.0/24` à `10.0.9.0/24`
- Homologation : `10.0.10.0/24` à `10.0.19.0/24`
- UAT : `10.0.20.0/24` à `10.0.29.0/24`
- Dev : `10.0.30.0/24` à `10.0.39.0/24`

## 🔄 Processus d'import

### 1. Ordre de traitement

**Étape 1 - Référentiels** :
1. Rôles IPAM
2. RIRs (Registres IP)
3. Régions
4. Tenants

**Étape 2 - Infrastructure** :
5. Sites
6. Providers
7. Types de circuits

**Étape 3 - Réseaux** :
8. Aggregates
9. Prefixes
10. Circuits

### 2. Validation des dépendances

**Avant l'import, vérifier** :
- Unicité des slugs
- Références croisées (tenant, region, etc.)
- Format des adresses IP
- Cohérence des ranges

## 📊 Monitoring et maintenance

### 1. Indicateurs clés

**Utilisation IP** :
```bash
# Vérifier l'utilisation des prefixes
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?status=active" | \
  jq '.results[] | {prefix: .prefix, utilization: .utilization}'
```

**Circuits actifs** :
```bash
# Lister les circuits par provider
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/" | \
  jq '.results | group_by(.provider.name)'
```

### 2. Maintenance préventive

**Sauvegarde régulière** :
```bash
# Export de la configuration
python3 manage.py dumpdata > netbox_backup_$(date +%Y%m%d).json
```

**Nettoyage périodique** :
- Suppression des objets obsolètes
- Mise à jour des descriptions
- Validation des références

## 🔍 Requêtes utiles

### 1. Recherche d'IP disponibles

```bash
# Trouver des IPs libres dans un prefix
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/1/available-ips/"
```

### 2. Rapport par tenant

```bash
# Prefixes par tenant production
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/ipam/prefixes/?tenant=prod&role=prod"
```

### 3. Circuits par région

```bash
# Circuits ExpressRoute par région
curl -H "Authorization: Token $NETBOX_TOKEN" \
  "$NETBOX_URL/api/circuits/circuits/?type=expressroute&region=northeurope"
```

## 🚨 Troubleshooting

### 1. Erreurs d'import courantes

**Erreur de token** :
```bash
# Test de connectivité
curl -I -H "Authorization: Token $NETBOX_TOKEN" "$NETBOX_URL/api/"
```

**Erreur de format CSV** :
```bash
# Vérifier l'encodage
file -bi fichier.csv
# Convertir si nécessaire
iconv -f ISO-8859-1 -t UTF-8 fichier.csv > fichier_utf8.csv
```

**Erreur de dépendance** :
```bash
# Vérifier l'ordre d'import
# Logs détaillés dans le script
```

### 2. Validation post-import

**Vérifications minimales** :
1. Tous les objets créés
2. Références croisées correctes
3. Hiérarchie des prefixes
4. Cohérence des circuits

---

**⚠️ Points d'attention** :
- Tester d'abord sur un environnement de dev
- Sauvegarder avant import
- Valider les ranges IP avant déploiement
- Documenter les personnalisations